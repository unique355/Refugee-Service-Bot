from flask import Flask, request, render_template_string, send_from_directory
import re

app = Flask(__name__)

# Clean emojis/surrogates
def clean_response(text):
    return re.sub(r'[\ud800-\udfff]', '', text)

# Dummy GPT-like response for testing without API
def get_response(user_input):
    if "library" in user_input.lower():
        return "You can find the nearest library near Kakuma town center."
    elif "gym" in user_input.lower():
        return "There’s a local gym facility not far from the UN compound. Here’s how to get there!"
    elif "business" in user_input.lower():
        return "To start a business, you’ll need to register it with your local authorities. I can guide you through the steps!"
    else:
        return "I'm PathFinder, your assistant! Ask me about nearby places, starting a business, or local service."

# HTML Template with improved styling
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>PathFinder Chatbot</title>
    <link rel="manifest" href="/manifest.json">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f4f8;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 720px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
            border-radius: 10px;
        }
        .logo {
            width: 120px;
            display: block;
            margin: 0 auto 10px;
        }
        h1 {
            text-align: center;
            color: #2c3e50;
        }
        form textarea {
            width: 100%%;
            padding: 10px;
            margin-top: 10px;
            font-size: 16px;
            border-radius: 5px;
        }
        button {
            background: #3498db;
            color: white;
            padding: 10px;
            margin-top: 10px;
            border: none;
            font-size: 16px;
            width: 100%%;
            border-radius: 5px;
        }
        .response {
            background: #ecf0f1;
            padding: 15px;
            margin-top: 20px;
            border-radius: 5px;
        }
        #map {
            height: 300px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="{{ url_for('static',filename='PathFinder_20250630_145843_0000') }}" class="logo" alt="PathFinder Logo">

        <h1>PathFinder Chatbot</h1>
        <form method="POST">
            <textarea name="user_input" placeholder="Ask about gyms, business, or schools..." required>{{ user_input }}</textarea>
            <button type="submit">Ask</button>
        </form>
        <div class="response"><strong>Bot:</strong> {{ response }}</div>
  
    </div>
    <script>
        // Voice recognition (Web Speech API)
        const button = document.querySelector('button');
        const textarea = document.querySelector('textarea');
        if ('webkitSpeechRecognition' in window) {
            const recognition = new webkitSpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'en-US';

            button.addEventListener('dblclick', () => {
                recognition.start();
            });

            recognition.onresult = function(e) {
                textarea.value = e.results[0][0].transcript;
            };
        }
    </script>
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def home():
    user_input = ""
    response_text = ""
    if request.method == "POST":
        user_input = request.form["user_input"]
        response_text = get_response(user_input)
    
    return render_template_string(HTML_TEMPLATE, user_input=user_input, response=response_text)

# Manifest for PWA
@app.route("/manifest.json")
def manifest():
    return {
        "name": "PathFinder Chatbot",
        "short_name": "PathFinder",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#f0f4f8",
        "theme_color": "#3498db",
        "icons": [
            {
                "src": "/static/logo.png",
                "type": "image/png",
                "sizes": "512x512"
            }
        ]
    }

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
