from flask import Flask, request, render_template, jsonify
import openai
import os

app = Flask(__name__)
openai.api_key = os.getenv("OPENAI_API_KEY")

def get_response(prompt, tone="enthusiastic"):
    if tone == "professional":
        system_msg = "You are a professional assistant that writes serious and compelling content."
    elif tone == "funny":
        system_msg = "You are a funny assistant who writes humorous social media content."
    elif tone == "friendly":
        system_msg = "You are a social media assistant who writes welcoming and engaging product descriptions."
    else:
        system_msg = "You are an enthusiastic assistant who writes persuasively explicit content with humour."

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt}
            ]
        )
        return response['choices'][0]['message']['content'].strip()
    except Exception as e:
        return f"Error: {str(e)}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    message = data.get("message")
    personality = data.get("personality", "enthusiastic")
    reply = get_response(message, personality)
    return jsonify({"response": reply})

if __name__ == '__main__':
    app.run(debug=True)
